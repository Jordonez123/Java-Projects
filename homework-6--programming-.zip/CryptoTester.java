public class CryptoTester {

    public static void main(String[] args) {


        //The message to encrypt and decrypt for all three cipher types
        String message = "Hello World!";

        
        //TEST Substitution (use this as a template for the other two)----------
        Encryptor eS = new Encryptor("substitution", 3);
        String secretS = eS.encrypt(message);
        Decryptor dS = new Decryptor("substitution", 3);
        String messageS = dS.decrypt(secretS);
        System.out.println("\n\nSUBSTITUTION\n------------\nSecret:\t\t" + secretS + "\nMessage:\t" + messageS);


        //TEST Additive---------------------------------------------------------
        //Your code goes here
        Encryptor a = new Encryptor("additive", 'p');
        String secret_two = a.encrypt(message);
        Decryptor b = new Decryptor("additive", 'p');
        String message_two = b.decrypt(secret_two);
        System.out.println("\n\nADDITIVE\n------------\nSecret:\t\t" + secret_two + "\nMessage:\t" + message_two);


        //TEST Transposition----------------------------------------------------
        Encryptor c = new Encryptor("transposition","Apple");
        String secret_three = c.encrypt(message);
        System.out.println("transposition secret: " + secret_three);
        Decryptor d = new Decryptor("transposition","Apple");
        String message_three = d.decrypt(secret_three);
        System.out.println("\n\nTransposition\n------------\nSecret:\t\t" + secret_three + "\nMessage:\t" + message_three);

        
    }
    

}