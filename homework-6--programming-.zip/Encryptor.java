//Add any classes you might need from the Java API

import java.util.Arrays;
public class Encryptor {



    /* INSTANCE VARIALBES-------------------------------------------------------
     *
     * Try not to change or add too many (if at all) other instance variables
     */
    private String cipher; //Will tell your encryptor which encryption technique to use
    private Object key; //The key for your encryption technique



    /* CONSTRUCTOR--------------------------------------------------------------
     * 
     * You can do it with just this one constructor or, if you would like, you 
     * could use (three) overloaded constructors. 
     * 
     * If you choose to use just one constructor, your constructor is going to
     * be pretty simple. However, your encrypt() method is going to need to 
     * convert the `key` instance variable from type `Object` to the key data 
     * type needed for whatever encryption technique is specified through the 
     * constructor argument `technique`. 
     * E.g. If cipher.equals("substitution") then, per the README, the key needs 
     * to be an integer. 
     * 
     * If you choose to use overloaded constructors, then your single instance
     * variable `Object key` will need to actually be three instance variables, 
     * each of the type required by each encryption techniques
     */
    public Encryptor(String technique, Object key) {

        /* Initializes your instance variables */
        cipher = technique.toLowerCase();
        this.key = key;
        

    }


    
    /* METHODS------------------------------------------------------------------
     * 
     * Below are all the methods you must implement. You can add more if needed
     */ 
    public String encrypt(String message) {

        /* Your only PUBLIC method; this is the sole method you'll use in your 
         * tester. Takes in a String message and returns a String encrypted
         * message 
         */
       String encrypted = "";
       if(cipher.equals("substitution")){
           int k = (int) key; //casting the key object into an int
           encrypted = encryptSubstitution(message,k);
       }
       if(cipher.equals("additive")){
            char l = (char)key; //casting the key object into a char
            encrypted = encryptAdditive(message,l);
        }
       if(cipher.equals("transposition")){
           String v = (String) key;//casting the key object into a String
           encrypted = encryptTransposition(message,v);
       }
        return encrypted;
    }


    private String encryptSubstitution(String message, Integer key) {

        /* Write your algorithm for the Substitution cipher here */
        int shift = key;
        String x = "";//encrypted string
        for (int i = 0; i<message.length();i++){
            int ch = (int) message.charAt(i);//current character
            System.out.println("ch is: " + ch);
            ch+=shift; //adding the shift value
            if(ch+shift>126){
                ch=ch-126+32-1;
                System.out.println("new value for ch: " + ch);
            }
            x+= (char) ch;
    
        }
        return x;

    }


    private String encryptAdditive(String message, Character key) {
        
        int key_num = (int) key;
        String x = ""; //encrypted string
        for (int i=0; i<message.length();i++){
            int xor_sum = (int) message.charAt(i) ^ key_num;//this is the result of xoring the two int values
            String xor_sumS = Integer.toString(xor_sum);
            x = x + xor_sumS + " ";
        }
        return x;

    }
    

    private String encryptTransposition(String message, String key) {
        String ke = key;
        String m = message;
        String key_caps = ke.toUpperCase();
        int rows = 0;
        if(m.length() % ke.length() != 0){
            rows = (int) (m.length()/ke.length()) +1;
        }else{
            rows = (int) (m.length()/ke.length());
        }
        rows+=2;
        int columns = ke.length();
        char [][]a = new char[rows][columns];
        for (int i = 0;i<rows;i++){
            for(int j = 0;j<columns;j++){
                a[i][j] = ' ';
            }
        }
        //writing out key across top row of the 2D array
        for (int x = 0;x<key_caps.length();x++){
            //going through every char in key_caps and depositing it in row 1 column x
            a[0][x] = key_caps.charAt(x);
        }
        //sorting out the characters in key_caps
        char [] unsorted_arr = key_caps.toCharArray();
        Arrays.sort(unsorted_arr);
        String sorted = new String(unsorted_arr);
        //writing out the message in the 2D array
        int message_position = 0;
        for(int e = 2; e<rows;e++){//parameters of the 2D array
            for(int f = 0; f<columns;f++){
                if(message_position<m.length()){
                    a[e][f] = m.charAt(message_position);
                    message_position+=1;
                }
            }
        }
        int key_order_position = 1;
        int array_column_position = 0;
        for (int j = 0; j<key_caps.length();j++){
            for (int k = 0; k<sorted.length();k++){
                if(key_caps.charAt(j) == sorted.charAt(k)){
                    key_order_position= k+1;
                    if(array_column_position<=columns){
                        //checking for repetitions, within the range
                        for(int u = 0; u<j;u++){
                            if(key_caps.charAt(j) == key_caps.charAt(u)){
                                key_order_position += 1;
                            }
                        }
                        //inputting these values into the 2D array second column
                        a[1][array_column_position] = (char)(key_order_position+'0');
                        array_column_position+=1;
                        break;
                    }
                }
            }
        }
        //now encrypting the string
        String encrypted = "";
        for (int w = 1; w<columns+1;w++){
            for (int y = 0; y<columns;y++){//iterating through the columns checking if values match the column position
                if(a[1][y] == (char) (w+'0')){
                    //adding corresponding vertical elements to 'encrypted' String
                    for (int q = 2;q<rows;q++){
                        encrypted+= a[q][y];
                    }
                }   
            }
        }
        return encrypted;
    }
}