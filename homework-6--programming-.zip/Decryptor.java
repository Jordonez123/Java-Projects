//Add any classes you might need from the Java API
import java.util.Arrays;
public class Decryptor {



    /* INSTANCE VARIALBES-------------------------------------------------------
    *
    * Try not to change or add too many (if at all) other instance variables
    */
    private String cipher;
    private Object key;



    /* CONSTRUCTOR--------------------------------------------------------------
     * 
     * You can do it with this one constructor or, if you would like, you could
     * use overloaded constructors. See Encryptor constructor for hints.
     */
    public Decryptor(String technique, Object key) {

        /* Initializes your instance variables */
        cipher = technique.toLowerCase();
        this.key = key;

    }



    /* METHODS------------------------------------------------------------------
    * 
    * Beloow are all the methods you must implement. You can add more if needed.
    */ 
    public String decrypt(String message) {

        /* Your only PUBLIC method; this is the sole method you'll use in your 
         * tester. Takes in a String encrypted message and returns a String 
         * human readable message.
         */
        String decrypted = "";
        if (cipher.equals("substitution")){
            int k = (int) key; //casting the key object into an int
            decrypted = decryptSubstitution(message, k);
        }
        if(cipher.equals("additive")){
            char l = (char)key; //casting the key object into a char
            decrypted = decryptAdditive(message, l);
        }
         if(cipher.equals("transposition")){
           String v = (String) key;//casting the key object into a String
           decrypted = decryptTransposition(message,v);
       }
        
        return decrypted;

    }


    private String decryptSubstitution(String secret, Integer key) {

        /* Write your algorithm to decrypt the Substitution cipher here */
        int shift = key;
        String dec = "";//deciphered string
        for(int i=0; i<secret.length(); i++){
            int ce = (char) secret.charAt(i); //assigning the char ascii to an int ce
            System.out.println("value taken for ce: " + ce);
            if(ce-shift<32){
                ce = ce-32+126-2;
                System.out.println("ce now is: " + ce);
            }else{
            ce-= shift;
            }
            System.out.println("ce now is: " + ce);
            dec+=(char) ce;
        }
        return dec;
    }


    private String decryptAdditive(String secret, Character key) {
        int key_val = (int) key;//ascii numerical value of key
        String deciphered = "";//deciphered string
        String num = ""; //used to get characters to the space
        for (int i = 0; i<secret.length();i++){
            if (secret.charAt(i) != ' '){
                num += secret.charAt(i);
            }
            if (i+1 < secret.length() && secret.charAt(i+1) == ' '){
                int num_val = Integer.parseInt(num);
                System.out.println(num_val);
                int xor_val = num_val ^ key_val;
                char a = (char) xor_val;
                deciphered+=a;
                num = "";
            }
        }
        return deciphered;
    }


    private String decryptTransposition(String secret, String key){
        String se = secret;
        String ke = key;
        String key_caps = ke.toUpperCase();
        //if doesn't evenly divide
        int rows = 0;
        if (se.length() % ke.length() != 0){
            rows = (int) (se.length()/ke.length()) +1;
        }else{
            rows = (int) (se.length()/ke.length());
        }
        rows+=2;
        int columns = ke.length();
        char[][]a = new char[rows][columns];
        for(int i = 0; i<rows;i++){
            for(int j = 0; j<columns;j++){
                a[i][j] = ' ';
            }
        }
        //writing out key across top row of the matrix
        for(int x = 0; x<key_caps.length(); x++){
            //going through every char in key_caps and depositing in column x
            a[0][x] = key_caps.charAt(x);
        }
        //sorting out the characters in key_caps
        char [] unsorted_arr = key_caps.toCharArray();
        Arrays.sort(unsorted_arr);
        String sorted = new String (unsorted_arr);
        int key_order_position = 0;
        int array_column_position = 0;
        for(int j = 0;j<key_caps.length();j++){
            for(int k = 0;k<sorted.length();k++){
                if(key_caps.charAt(j) == sorted.charAt(k)){
                    key_order_position = k+1;
                    if(array_column_position<=columns){
                        //checking for repetitions, within the range
                        for(int u = 0; u<j;u++){
                            if(key_caps.charAt(j) == key_caps.charAt(u)){
                                key_order_position+=1;
                            }
                        }
                        //inputting these values into the 2D array second column
                        a[1][array_column_position] = (char)(key_order_position+'0');
                        array_column_position+=1;
                        break;
                    }
                }
            }
        }
        //writing out the message
        int message_position = 0;
        int compare_column = 1;
        for(int w = 0; w<columns;w++){
            for(int q = 0; q<columns;q++){
                if(a[1][q] == (char) (compare_column + '0')){
                    for(int n = 2; n<rows;n++){
                        a[n][q] = se.charAt(message_position);
                        if(message_position+1<se.length()){
                            message_position+=1;
                        }
                    }
                }
            }
            compare_column+=1;
        }
        //decrypting the string
        String de = "";
        for(int f = 2; f<rows;f++){
            for(int z = 0; z< columns;z++){
                de+=a[f][z];
            }
        }
        return de;
    }
}