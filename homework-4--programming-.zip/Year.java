/*
 * 
 * Jordan Ordonez Chaguay: jio2108
 * October 11, 2019
 * 
 * Strategy:
 * 
 * For my conditional statements, I looked for the case
 * when a number that is above 1582 would return as not being a leap year.
 * 
 * This happens when it is not divisible by 100 and when the number
 * is neither divisible by 4 and by 400
 * 
 * I made an instance variable of type boolean which is changed to
 * either true or false when the conditions is passed or not. 
 * 
 * Then at the end of the program, I simply returned the value of the 
 * boolean variable*/


public class Year{
    
    // declare your instance variables here
    private boolean L;



    // write your constructor here

    public Year(int y){
        // your code here
        
        if( (y % 100 == 0) && !((y % 400 == 0) && (y % 4 == 0))){
            L = false;
            
        }else{
            L = true;
        }
    }


    public boolean isLeapYear(){ /*here we should return a string, 
    to say if y is a leap year or not, check if boolean L is still true*/
        // your code here 
         return L;
        
    }

}    

