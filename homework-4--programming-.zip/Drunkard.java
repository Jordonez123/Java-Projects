/*
 * 
 * Jordan Ordonez Chaguay: jio2108
 * October 11, 2019
 * 
 * Strategy: 
 * 
 * I first imported the Random package from java util in order to
 * make a random number generator.
 * 
 * I made 4 private instance variables of type int, two to retrieve
 * the intial x and y position and two copies of these two positions
 * one for each x and y (I called them private int a and private int b).
 * 
 * The purpose of making copies of the original positions is to be able
 * to manipulate them when reassigning the values once the random choice
 * (up, down, right, left) has been made.
 * 
 * I used the Integer().toString() method for the getLocation() method
 * in order to convert the integer, representing the x and y location, into
 * string types (to later make a string combining these two positions).
 * 
 * Since the howFar() method returns the current distance from the starting
 * position in Manahattan Distance, I just needed to find the absolute value of the 
 * diffference in current and starting position (since we can have negative numbers). */





import java.util.Random;

public class Drunkard{
    
    private int x;
    private int y;
    private int a;
    private int b;
    
    public Drunkard (int avenue,int street){
    
        x = avenue;//keeps original avenue position
        y = street;//keeps original street position
        a = x; //copy of x to later manipulate 
        b = y; // copy of y to later manipulate
        
        
    }
    public void step(){
        Random generator = new Random();//creating a random number generator
        
        int rand = generator.nextInt(4); //posible values for rand: 0,1,2,3
        
        if (rand==0){//move up
            b+=1;
        }
        
        if (rand==1){//move down
            b-=1;
            
        }
        
        if(rand==2){//move right
            a+=1;
        }
        
        if (rand==3){//move left
            a-=1;
        }
 
        
    }
    public void fastForward(int steps){
        
        for (int i = 1; i<=steps;i++ ){
           
            step(); //calling the step function for as many times as " int steps"
        }
        
    }
    public String getLocation(){
        
        String ave = new Integer(a).toString();/*converting the int a (avenue)
                                                * to a String*/
        
        String st = new Integer(b).toString();/*converting the int b(street)
                                               * to a String*/
        
        String location = ave + " Avenue" + ", " + st + " Street";
        
        return location;
    }
    
    public int howFar(){
        
        int count = Math.abs(a-x)+Math.abs(b-y); /*calculating the absolute differences 
                                                  * and adding their values together*/
        return count;
    }
}