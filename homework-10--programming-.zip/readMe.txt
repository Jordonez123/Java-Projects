My program allows the user to enter in two text files into the command line
(post-compilation).
The first text file is one containing information regarding login attempts
from users with specific ip addresses.
The second text file is (one which the user chooses to name) where the
results of the program will be written to. 

How and why I chose to design my code the way I did:
I looked over at the lecture notes posted on Courseworks under "Files"
in order to look at previous examples regarding Printer, ArrayLists,
reading information from a file, and hanling I/O exceptions.

One of the first things that I made sure to do was to import the necessary
packages needed to complete the assignment. 

Some of the methods that I saw where going to be of great help to finish
the assingment were .equals(), sort() [this one being noted as Collections.sort()],
and .split()

In the next few lines of code, I made sure to create two String ArrayLists.
The first one called invalids and the second one called invalids.
The idea here was to iterate through all of the lines in the file that Scanner
in was reading and figuring out which line had the string "Invalid."
From here, we would collect all of the IP addresses from the lines
that had "Invalid" and put them into an ArrayList that we could iterate
through. 

Once I got all of the IP addresses that had been with failed login attempts
into an ArrayList, I decided to sort the list. This would make counting
the frequency of the each "Invalid IP address" much easier than if had been
unsorted. 

The last bit of code deals with finding the frequency of which the
IP addresses occur. I chose to iterate through through the size of the recently
created ArrayList of invalid IP addresses. The outer for loop keeps constant the
IP address that we are comparing against to and the inner for loop compares
all of the IP addresses in the ArrayList against that one. If they match(using .equals()
for String objects), then we increase the value of the counter called invalid_counter.
If the value of the counter is equal to 3 at any one point we add the IP address to the second
ArrayList called ip_fail (only if it is not alredy contained) and finally we break, 
knowing that this IP address has repeated for 3 or more times.

Finally, I created a PrinWriter object which creates a file put by the user in the
command line. This PrintWriter prints every item in the ip_fail ArrayList. 
At the end, we make sure to close the file.