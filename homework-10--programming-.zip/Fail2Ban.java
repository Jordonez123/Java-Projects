/*Jordan I. Ordonez Chaguay
 * jio2108
 * December 9, 2019*/

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Fail2Ban{
    public static void main (String [] args)throws FileNotFoundException{
        ArrayList<String> invalids = new ArrayList<String>(); //includes invalid attempts
        ArrayList<String> ip_fail = new ArrayList<String> ();//invalids w/ >=3 fails
        File f = new File(args[0]);
        Scanner in = new Scanner(f);
        int line_count = 0;
        int invalid_counter = 0;
        while(in.hasNextLine()){
            line_count += 1;
            String line = in.nextLine();
            String [] words = line.split(" ");
           //checking if the word Invalid is in the read line
            for(String s:words){
                if (s.equals("Invalid")){
                    invalids.add(words[9]); 
                }
             }
        }
        //sorting the ArrayList of invalid attempt IP addresses
        Collections.sort(invalids);
        
        //checking if each ip in invalids list occurs more than once

        for (int j = 0;j<invalids.size();j++){
            invalid_counter = 0; //keeps track of frequency of IP address
            for(int k = 0;k<invalids.size();k++){
                if (invalids.get(j).equals(invalids.get(k))){
                    invalid_counter +=1;
                    if (invalid_counter == 3){
                        //checking if IP address is already in the ip_fail
                        if(ip_fail.contains(invalids.get(j))){
                            break;
                        }else{
                            //adding IP address with frequency >=3
                            ip_fail.add(invalids.get(j));
                            break;
                        }
                    }
                }
            }
            
        }
            
       
        //printing a list of ip addresses to a new .txt
        PrintWriter pw = new PrintWriter(args[1]);
        pw.println("The ip addresses that failed >=3 times in: " + f);
        pw.println("");
        for (String fail:ip_fail){
            pw.println(fail);
        }
        pw.close();
    }
}